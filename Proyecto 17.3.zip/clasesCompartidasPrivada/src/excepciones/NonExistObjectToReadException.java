package excepciones;

public class NonExistObjectToReadException extends Exception 
{
	 public NonExistObjectToReadException(String msg) 
	 {
		 super(msg);
	 }

}
