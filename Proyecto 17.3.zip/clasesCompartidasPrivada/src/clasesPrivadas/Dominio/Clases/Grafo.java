package clasesPrivadas.Dominio.Clases;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/*
author: 
*/
import clasesCompartidas.ConjuntoNodos;
import clasesCompartidas.Pair;


/**
 * @author Domingo Jes�s de la Mata Garcia
 *
 */
public class Grafo implements Serializable
{

	//private static final long serialVersionUID = -8219161298749272356L;
	
	static final String RUTA_INICIAL = "Set1";
	static final String RUTA_ADD = "AddData";
	static final String FILTROS = "Filtros";
	
	ConjuntoNodosPri authors;
	ConjuntoNodosPri therms;
	ConjuntoNodosPri conferences;
	ConjuntoNodosPri papers;
	
	RelacionesPri PAF;
	RelacionesPri PAC;
	RelacionesPri PCF;
	RelacionesPri PCC;
	RelacionesPri PTF;
	RelacionesPri PTC;
	
	public Grafo()
	{
		//(0 = P, 1 = A, 2 = C, 3 = T)  
		//(1 = PA, 2 = PC, 3 = PT)  
		//No estoy seguro de lo que hace el ID libre
		try 
		{
			Pair<HashMap<Integer,String>,HashMap<String,Integer>> conjunto;
			Pair<HashMap<Integer,ArrayList<Pair<Integer,Double>>>,HashMap<Integer,ArrayList<Pair<Integer,Double>>>> relacion;
			
			//Instanciamos papers
			conjunto = LeerFichero.crear_nodo_primitivo(RUTA_INICIAL, 0);
			
			this.papers = new ConjuntoNodosPri(conjunto.getFirst(),conjunto.getSecond());
			
			//Instanciamos autor
			conjunto = LeerFichero.crear_nodo_primitivo(RUTA_INICIAL, 1);
			
			this.authors = new ConjuntoNodosPri(conjunto.getFirst(),conjunto.getSecond());
			
			//Instanciamos conferences
			conjunto = LeerFichero.crear_nodo_primitivo(RUTA_INICIAL, 2);
			
			this.conferences = new ConjuntoNodosPri(conjunto.getFirst(),conjunto.getSecond());
			
			//Instanciamos terms
			conjunto = LeerFichero.crear_nodo_primitivo(RUTA_INICIAL, 3);
			
			this.therms = new ConjuntoNodosPri(conjunto.getFirst(),conjunto.getSecond());
			
			//Instanciamos Relacion PA
			relacion = LeerFichero.crear_relacion(RUTA_INICIAL, 1);
			//Debemos encontrar una forma mejor de hacer esto
			this.PAF = new RelacionesPri(relacion.getFirst(),relacion.getSecond());
			relacion = LeerFichero.crear_relacion(RUTA_INICIAL, 1);
			this.PAC = new RelacionesPri(relacion.getFirst(),relacion.getSecond());
			//this.PAC = (RelacionesPri)PAF.clone();
			//this.PAC = new RelacionesPri(PAF);
			
			//Creo que es SUPER ineficiente
			this.PAF.ordenarArray();
			this.PAC.ordenarArray();
			
			this.PAF.normFilas();
			this.PAC.normColumnas();
			
			
			//Instanciamos Relacion PC
			relacion = LeerFichero.crear_relacion(RUTA_INICIAL, 2);
			this.PCF = new RelacionesPri(relacion.getFirst(),relacion.getSecond());
			relacion = LeerFichero.crear_relacion(RUTA_INICIAL, 2);
			this.PCC = new RelacionesPri(relacion.getFirst(),relacion.getSecond());
			//this.PCC = (RelacionesPri)PAF.clone();
			//this.PCC = new RelacionesPri(PAF);
			
			//Creo que es SUPER ineficiente
			this.PCF.ordenarArray();
			this.PCC.ordenarArray();
			
			this.PCF.normFilas();
			this.PCC.normColumnas();
			
			//Instanciamos Relacion PT
			relacion = LeerFichero.crear_relacion(RUTA_INICIAL, 3);
			this.PTF = new RelacionesPri(relacion.getFirst(),relacion.getSecond());
			relacion = LeerFichero.crear_relacion(RUTA_INICIAL, 3);
			this.PTC = new RelacionesPri(relacion.getFirst(),relacion.getSecond());
			//this.PTC = (RelacionesPri)PAF.clone();
			//this.PTC = new RelacionesPri(PAF);
			
			//Creo que es SUPER ineficiente
			this.PTF.ordenarArray();
			this.PTC.ordenarArray();
			
			this.PTF.normFilas();
			this.PTC.normColumnas();
			
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Se ha producido un error en la creacion del objeto grafo.");
		}
	}
	
	
	private void escribirDataSet()
	{
		//(0->P  1->A  2->C 3->T)
		EscribirFichero.ReescribirFicheroNodos(papers.devolver_conjunto(), 0);
		EscribirFichero.ReescribirFicheroNodos(authors.devolver_conjunto(), 1);
		EscribirFichero.ReescribirFicheroNodos(conferences.devolver_conjunto(), 2);
		EscribirFichero.ReescribirFicheroNodos(therms.devolver_conjunto(), 3);
	}
	
	private void escribirRelaciones()
	{
		//(0->PA  1->PC  2->PT)
		EscribirFichero.ReescribirFicheroRelaciones(PAF.getRelacionesEscritura(), 0);
		EscribirFichero.ReescribirFicheroRelaciones(PCF.getRelacionesEscritura(), 1);
		EscribirFichero.ReescribirFicheroRelaciones(PTF.getRelacionesEscritura(), 2);
	}
		
	//TODO
	//Hay que modificar implementacion
	//b indica si devuelve la matriz normalizada por filas o por columnas
	//b = true -> filas
	//b = false -> columnas
	public HashMap<Integer,ArrayList<Pair<Integer,Double>>> getRelaciones(String rel, boolean b)
	{
		if (rel.equals("AP")){
			if (b) return this.PAF.consultar_OtherPaper();
			else return this.PAC.consultar_OtherPaper();
		}
		else if (rel.equals("PA")){
			if(b) return this.PAF.consultar_PaperOther();
			else return this.PAC.consultar_PaperOther();
		}
		else if (rel.equals("CP")){
			if (b) return this.PCF.consultar_OtherPaper();
			else return this.PCC.consultar_OtherPaper();
		}
		else if (rel.equals("PC")){
			if(b) return this.PCF.consultar_PaperOther();
			else return this.PCC.consultar_PaperOther();
		}
		else if (rel.equals("TP")){
			if (b) return this.PTF.consultar_OtherPaper();
			else return this.PTC.consultar_OtherPaper();
		}
		else
		{
			if(b) return this.PTF.consultar_PaperOther();
			else return this.PTC.consultar_PaperOther();
		}
	}
	
	public void anadirNodo(Integer type, String name)
	{
		//(0 = P, 1 = A, 2 = C, 3 = T)
		switch(type)
		{
			case 0	:	this.papers.anadir_nodo(name);
						break;
			
			case 1	:	this.authors.anadir_nodo(name);
						break;
			
			case 2	:	this.conferences.anadir_nodo(name);
						break;
			
			case 3	:	this.therms.anadir_nodo(name);
						break;
		}
	}
	
	
	public void anadirRelacion(int a, int b, int tipo)
	{
		 //(1 = PA, 2 = PC, 3 = PT)
		switch(tipo)
		{
			case 1	:	this.PAF.anadir_PaperOther(a, b);
						this.PAC.anadir_PaperOther(a, b);
						this.PAF.ordenarArray();
						this.PAC.ordenarArray();
						this.PAF.normFilas();
						this.PAC.normColumnas();
						break;
			
			case 2	:	this.PCF.anadir_PaperOther(a, b);
						this.PCC.anadir_PaperOther(a, b);
						this.PCF.ordenarArray();
						this.PCC.ordenarArray();
						this.PCF.normFilas();
						this.PCC.normColumnas();
						break;
			
			case 3	:	this.PTF.anadir_PaperOther(a, b);
						this.PTC.anadir_PaperOther(a, b);
						this.PTF.ordenarArray();
						this.PTC.ordenarArray();
						this.PTF.normFilas();
						this.PTC.normColumnas();
						break;
		}
	}
	
	public int consultarNodo(int type, String name)
	{
		//(0 = P, 1 = A, 2 = C, 3 = T)
		switch(type)
		{
			case 0	:	return this.papers.consultar_nodo(name);
			
			case 1	:	return this.authors.consultar_nodo(name);
			
			case 2	:	return this.conferences.consultar_nodo(name);
			
			default	:	return this.therms.consultar_nodo(name);
		}
	}
	
	public String consultarNodo(int type, int id)
	{
		//(0 = P, 1 = A, 2 = C, 3 = T)
		switch(type)
		{
			case 0	:	return this.papers.consultar_nodo(id);
			
			case 1	:	return this.authors.consultar_nodo(id);
			
			case 2	:	return this.conferences.consultar_nodo(id);
			
			default	:	return this.therms.consultar_nodo(id);
		}
	}
	
	public void eliminarNodo(int type, int id) throws NullPointerException
	{
		//(0 = P, 1 = A, 2 = C, 3 = T)
		ArrayList<Pair<Integer,Double>> conjunto;
		ArrayList<Pair<Integer,Double>> conjunto2;
		int tam;
		switch(type)
		{
			case 0	:	//--------------------
						conjunto = this.PAF.consultar_RelacionPaper(id);
						conjunto2 = this.PAC.consultar_RelacionPaper(id);
						//System.out.println("papers" + conjunto);
						if(conjunto != null)
						{
							tam = conjunto.size();
							for(int i=0; i< tam; i++)
							{
								this.PAF.eliminar_PaperOther(id, conjunto.get(0).getFirst());
								this.PAC.eliminar_PaperOther(id, conjunto2.get(0).getFirst());
								this.PAF.normFilas();
								this.PAC.normColumnas();
								
							}
						}
						
						//TODO
						//REVISAR
						conjunto = this.PCF.consultar_RelacionPaper(id);
						conjunto2 = this.PCC.consultar_RelacionPaper(id);
						if(conjunto != null)
						{
							tam = conjunto.size();
							for(int i=0; i< tam; i++)
							{
								this.PCF.eliminar_PaperOther(id, conjunto.get(0).getFirst());
								this.PCC.eliminar_PaperOther(id, conjunto2.get(0).getFirst());
								this.PCF.normFilas();
								this.PCC.normColumnas();
							}
						}
						
						conjunto = this.PTF.consultar_RelacionPaper(id);
						conjunto2 = this.PTC.consultar_RelacionPaper(id);
						if(conjunto != null)
						{
							tam = conjunto.size();
							for(int i=0; i< tam; i++)
							{
								this.PTF.eliminar_PaperOther(id, conjunto.get(0).getFirst());
								this.PTC.eliminar_PaperOther(id, conjunto2.get(0).getFirst());
								this.PTF.normFilas();
								this.PTC.normColumnas();
							}
						}
						//TODO
						//REVISAR
						this.papers.eliminar_nodo(Integer.toString(id));
						
						//--------------------
						break;
			
			case 1	:	//--------------------
						System.out.println("elimiando autor");
						conjunto = this.PAF.consultar_RelacionOther(id);
						conjunto2 = this.PAC.consultar_RelacionOther(id);
						if(conjunto != null)
						{
							tam = conjunto.size();
							for(int i=0; i< tam; i++)
							{
								this.PAF.eliminar_PaperOther(conjunto.get(0).getFirst(), id);
								this.PAC.eliminar_PaperOther(conjunto2.get(0).getFirst(), id);
								this.PAF.normFilas();
								this.PAC.normColumnas();
							}
						}
						this.authors.eliminar_nodo(Integer.toString(id));
						//--------------------
						break;
			 
			case 2	:	//--------------------
						conjunto = this.PCF.consultar_RelacionOther(id);
						conjunto2 = this.PCC.consultar_RelacionOther(id);
						if(conjunto != null)
						{
							tam = conjunto.size();
							for(int i=0; i< tam; i++)
							{
								this.PCF.eliminar_PaperOther(conjunto.get(0).getFirst(), id);
								this.PCC.eliminar_PaperOther(conjunto2.get(0).getFirst(), id);
								this.PCF.normFilas();
								this.PCC.normColumnas();
							}
						}
						this.conferences.eliminar_nodo(Integer.toString(id));
						this.PCF.pinta_matriz();
						//--------------------
						break;
			
			default	:	//--------------------
						conjunto = this.PTF.consultar_RelacionOther(id);
						conjunto2 = this.PTC.consultar_RelacionOther(id);
						if(conjunto != null)
						{
							tam = conjunto.size();
							for(int i=0; i< tam; i++)
							{
								this.PTF.eliminar_PaperOther(conjunto.get(0).getFirst(), id);
								this.PTC.eliminar_PaperOther(conjunto2.get(0).getFirst(), id);
								this.PTF.normFilas();
								this.PTC.normColumnas();
							}
						}
						this.therms.eliminar_nodo(Integer.toString(id));
						//--------------------
						break;
		}
	}
	public void escribirDatos()
	{
		this.escribirDataSet();
		this.escribirRelaciones();
	}
	
	//Creo innecesario el throw
	//public void addDataGraph() throws FileNotFoundException
	public void addDataGraph()
	{
		// ruta definidia -> /AddData
		// Comprobar existencia de los ficheros
		//unir hashmaps con hashmap.putall(hashmap)
		try
		{
			LeerFichero.correcto(RUTA_ADD, RUTA_INICIAL);
			
			//(0 = P, 1 = A, 2 = C, 3 = T)  
			this.papers.joinHashMap(LeerFichero.crear_nodo_primitivo(RUTA_ADD, 0));
			this.authors.joinHashMap(LeerFichero.crear_nodo_primitivo(RUTA_ADD, 1));
			this.conferences.joinHashMap(LeerFichero.crear_nodo_primitivo(RUTA_ADD, 2));
			this.therms.joinHashMap(LeerFichero.crear_nodo_primitivo(RUTA_ADD, 3));
			
			//HAY QUE HABLAR CON PAU EL TEMA DE LAS NOMALIZACIONES
			//SOY CONSCIENTE DE QUE NO ES EFICIENTE PERO CON LE TIEMPO QUE TENEMOS VAMOS A CENTRARNOS EN TERMINAR Y LUEGO OPTIMIZAMOS
			//(1 = PA, 2 = PC, 3 = PT)  
			this.PAF.joinHashMap(LeerFichero.crear_relacion(RUTA_ADD, 1));
			this.PAC.joinHashMap(LeerFichero.crear_relacion(RUTA_ADD, 1));
			this.PAF.ordenarArray();
			this.PAC.ordenarArray();
			this.PAF.normFilas();
			this.PAC.normColumnas();
			
			this.PCF.joinHashMap(LeerFichero.crear_relacion(RUTA_ADD, 2));
			this.PCC.joinHashMap(LeerFichero.crear_relacion(RUTA_ADD, 2));
			this.PCF.ordenarArray();
			this.PCC.ordenarArray();
			this.PCF.normFilas();
			this.PCC.normColumnas();
			
			this.PTF.joinHashMap(LeerFichero.crear_relacion(RUTA_ADD, 3));
			this.PTC.joinHashMap(LeerFichero.crear_relacion(RUTA_ADD, 3));
			this.PTF.ordenarArray();
			this.PTC.ordenarArray();
			this.PTF.normFilas();
			this.PTC.normColumnas();
			
		}
		catch(Exception e)
		{
			System.out.println("Se ha producido un problema en la insercion de datos adicionales.");
		}
	}
}
