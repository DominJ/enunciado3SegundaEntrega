package clasesPrivadas.Dominio.Clases;
import clasesPrivadas.Dominio.Clases.*;

/**
 * @author Xavi Campos Navarro
 *
 */
public class MiPrograma {
	public static void main (String[] args) {
		javax.swing.SwingUtilities.invokeLater (new Runnable() {
			public void run() {
					CtrlPresentacion ctrlPresentacion = new CtrlPresentacion();
				
			} 
		});
	} 
}





